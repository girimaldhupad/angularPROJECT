# ganatan-backend
# 06/08/19 15:24

pm2 start process.config.js --env prod
pm2 startup
pm2 save

